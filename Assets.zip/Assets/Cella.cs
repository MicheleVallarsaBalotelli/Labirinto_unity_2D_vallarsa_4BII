using UnityEngine;

public class Cella
{
    public bool visitata;
    public bool[] muri;

    public Cella()
    {
        visitata = false;
        muri = new bool[4] { true, true, true, true };
        // 0 = Nord
        // 1 = Sud
        // 2 = Est
        // 3 = Ovest
    }
}

