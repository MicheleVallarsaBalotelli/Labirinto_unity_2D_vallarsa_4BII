using UnityEngine;

public enum Difficolta
{
    Facile,
    Medio,
    Difficile
}

public class GameManager : MonoBehaviour
{
    [Header("Riferimenti")]
    public GeneraLabirinto generatore;
    public GameObject playerPrefab;
    public Timer timer;

    [Header("Difficolt�")]
    public Difficolta difficolta = Difficolta.Facile;

    private GameObject player;
    private int livello = 1;

    void Start()
    {
        AvviaLivello();
    }

    public void AvviaLivello()
    {
        ImpostaDimensioni();

        generatore.Genera();

        SpawnaPlayer();

        if (timer != null)
        {
            timer.ResetTimer();
        }
    }

    void ImpostaDimensioni()
    {
        if (difficolta == Difficolta.Facile)
        {
            generatore.larghezza = 8 + livello;
            generatore.altezza = 8 + livello;
        }
        else if (difficolta == Difficolta.Medio)
        {
            generatore.larghezza = 12 + livello;
            generatore.altezza = 12 + livello;
        }
        else // Difficile
        {
            generatore.larghezza = 18 + livello;
            generatore.altezza = 18 + livello;
        }
    }

    void SpawnaPlayer()
    {
        if (player != null)
        {
            Destroy(player);
        }

        Vector3 startPos = generatore.GetStartPosition();
        player = Instantiate(playerPrefab, startPos, Quaternion.identity);
    }

    public void NuovoLivello()
    {
        livello++;
        AvviaLivello();
    }
}
