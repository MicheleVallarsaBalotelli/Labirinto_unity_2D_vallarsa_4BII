using UnityEngine;

public class MovimentoGiocatore : MonoBehaviour
{
    public float velocita = 5f;
    Rigidbody2D rb;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void FixedUpdate()
    {
        float x = Input.GetAxis("Horizontal"); // freccette o A/D
        float y = Input.GetAxis("Vertical");   // freccette o W/S

        rb.linearVelocity = new Vector2(x, y) * velocita;
    }
}
