using UnityEngine;
using TMPro; 

public class Timer : MonoBehaviour
{
    public TMP_Text testo; 
    private float tempo;

    void Update()
    {
        tempo += Time.deltaTime;
        testo.text = "Tempo: " + tempo.ToString("F1");
    }

    public void ResetTimer()
    {
        tempo = 0f;
    }
}
