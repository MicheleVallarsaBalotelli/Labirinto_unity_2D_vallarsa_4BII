using UnityEngine;
using System.Collections.Generic;

public class GeneraLabirinto : MonoBehaviour
{
    [Header("Dimensioni")]
    public int larghezza = 10;
    public int altezza = 10;
    public float dimensioneCella = 1f;

    [Header("Prefab")]
    public GameObject prefabMuro;
    public GameObject prefabUscita;

    private Cella[,] griglia;

    // ===================== API PUBBLICA =====================

    public void Genera()
    {
        CancellaLabirintoPrecedente();

        griglia = new Cella[larghezza, altezza];

        for (int x = 0; x < larghezza; x++)
        {
            for (int y = 0; y < altezza; y++)
            {
                griglia[x, y] = new Cella();
            }
        }

        GeneraDaCella(0, 0);
        DisegnaLabirinto();
        CreaUscita();
    }

    public Vector3 GetStartPosition()
    {
        return CalcolaCentroCella(0, 0);
    }

    // ===================== GENERAZIONE =====================

    void GeneraDaCella(int x, int y)
    {
        griglia[x, y].visitata = true;

        List<Vector2Int> vicini = OttieniVicini(x, y);

        while (vicini.Count > 0)
        {
            int indice = Random.Range(0, vicini.Count);
            Vector2Int prossimo = vicini[indice];
            vicini.RemoveAt(indice);

            if (!griglia[prossimo.x, prossimo.y].visitata)
            {
                RimuoviMuro(x, y, prossimo.x, prossimo.y);
                GeneraDaCella(prossimo.x, prossimo.y);
            }
        }
    }

    List<Vector2Int> OttieniVicini(int x, int y)
    {
        List<Vector2Int> lista = new List<Vector2Int>();

        if (x > 0) lista.Add(new Vector2Int(x - 1, y));
        if (x < larghezza - 1) lista.Add(new Vector2Int(x + 1, y));
        if (y > 0) lista.Add(new Vector2Int(x, y - 1));
        if (y < altezza - 1) lista.Add(new Vector2Int(x, y + 1));

        return lista;
    }

    void RimuoviMuro(int x1, int y1, int x2, int y2)
    {
        if (x1 == x2)
        {
            if (y1 > y2)
            {
                griglia[x1, y1].muri[1] = false;
                griglia[x2, y2].muri[0] = false;
            }
            else
            {
                griglia[x1, y1].muri[0] = false;
                griglia[x2, y2].muri[1] = false;
            }
        }
        else
        {
            if (x1 > x2)
            {
                griglia[x1, y1].muri[3] = false;
                griglia[x2, y2].muri[2] = false;
            }
            else
            {
                griglia[x1, y1].muri[2] = false;
                griglia[x2, y2].muri[3] = false;
            }
        }
    }

    // ===================== DISEGNO =====================

    void DisegnaLabirinto()
    {
        for (int x = 0; x < larghezza; x++)
        {
            for (int y = 0; y < altezza; y++)
            {
                Vector3 centro = CalcolaCentroCella(x, y);

                if (griglia[x, y].muri[0])
                    CreaMuro(centro + Vector3.up * dimensioneCella / 2f, 0f);

                if (griglia[x, y].muri[1])
                    CreaMuro(centro - Vector3.up * dimensioneCella / 2f, 0f);

                if (griglia[x, y].muri[2])
                    CreaMuro(centro + Vector3.right * dimensioneCella / 2f, 90f);

                if (griglia[x, y].muri[3])
                    CreaMuro(centro - Vector3.right * dimensioneCella / 2f, 90f);
            }
        }
    }

    void CreaMuro(Vector3 posizione, float rotazione)
    {
        Instantiate(
            prefabMuro,
            posizione,
            Quaternion.Euler(0f, 0f, rotazione),
            transform
        );
    }

    // ===================== USCITA =====================

    void CreaUscita()
    {
        Vector3 pos = CalcolaCentroCella(larghezza - 1, altezza - 1);
        Instantiate(prefabUscita, pos, Quaternion.identity);
    }

    // ===================== UTILS =====================

    Vector3 CalcolaCentroCella(int x, int y)
    {
        float offsetX = -larghezza * dimensioneCella / 2f + dimensioneCella / 2f;
        float offsetY = -altezza * dimensioneCella / 2f + dimensioneCella / 2f;

        return new Vector3(
            x * dimensioneCella + offsetX,
            y * dimensioneCella + offsetY,
            0f
        );
    }

    void CancellaLabirintoPrecedente()
    {
        foreach (Transform figlio in transform)
        {
            Destroy(figlio.gameObject);
        }
    }
}
