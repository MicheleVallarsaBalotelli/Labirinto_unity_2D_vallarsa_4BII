using UnityEngine;

public class CameraLabirinto : MonoBehaviour
{
    public GeneraLabirinto generatore;
    public float margine = 1.5f;

    Camera cam;

    void Awake()
    {
        cam = GetComponent<Camera>();
        cam.orthographic = true;
    }

    public void AggiornaCamera()
    {
        float larghezza = generatore.larghezza * generatore.dimensioneCella;
        float altezza = generatore.altezza * generatore.dimensioneCella;

        // centro del labirinto (0,0 perch� lo abbiamo centrato)
        transform.position = new Vector3(0f, 0f, -10f);

        // calcolo dimensione
        float rapporto = (float)Screen.width / Screen.height;

        float sizeVerticale = altezza / 2f;
        float sizeOrizzontale = (larghezza / 2f) / rapporto;

        cam.orthographicSize = Mathf.Max(sizeVerticale, sizeOrizzontale) + margine;
    }
}
